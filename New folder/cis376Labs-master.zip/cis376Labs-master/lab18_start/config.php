<?php
define('DBHOST', '192.168.1.7');
define('DBNAME', 'Login');
define('DBUSER', 'root');
define('DBPASS', '');
define('DBCONNSTRING','mysql:host=192.168.1.7;dbname=Login');
?>