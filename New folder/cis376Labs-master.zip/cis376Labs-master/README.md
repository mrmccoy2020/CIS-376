# cis376Labs
Downloads for the labs for CIS376

This is a read-only style repository that houses the files we will be using for our labs.  

You will want to create a feature branch based off the master for your work (you can push changes to the feature branch as you wish).  
Clone the feature branch to your local workspace and then fetch.  
