var continents = ["Asia", "Africa", "Europe", "North America", "South America" ];

var countries = ["Bahamas", "Canada", "Germany", "Ghana", "Hungary", "Italy", "Spain", "United Kingdom", "United States"];

var posts = [
    { id : 1, user : "Leonie Kohler", postdate : "2/4/2011", thumb : "6592294487.jpg", title : "Calgary in the Snow", excerpt : "In December of 2011, I was lucky/unfortunate enough to have the opportunity to fly to chilly Calgary in Western Canada for a week-long conference." },
    
    { id : 3, user : "Frantisek  Wichterlovar", postdate : "9/3/2011", thumb : "6114904363.jpg", title : "Mountain Climbing", excerpt : "The highlight of our last trip to Canada was a climb up Sulpher Mountain just outside of Banff. I'd like to say that it was so difficult that we required crampons, pitons, and screamers but that would be stretching the truth for sure." },
    
    { id : 9, user : "Edward Francisr", postdate : "3/19/2012", thumb : "5856697109.jpg", title : "Nova Scotia", excerpt : "The steamer Mongolia, belonging to the Peninsular and Oriental Company, built of iron, of two thousand eight hundred tons burden, and five hundred horse-power, was due at eleven o'clock a.m. on Wednesday, the 9th of October, at Suez." }    

];  

 
  