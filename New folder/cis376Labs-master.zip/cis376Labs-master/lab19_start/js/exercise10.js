$(function () {
    $('.animLoading').show();
    
    var url = "http://www.randyconnolly.com/funwebdev/services/travel/cities.php";
    var param = "iso=CA";
    
    // make request for list of cities for specified country
    
    
    // display map for selected city 
    function displayMap(selectedCity) {

    }


});